package com.mphasis.harsha.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="transaction_details")
public class TransactionDetails {
	@Id
	private String transaction_id;
	private Date dot;
	private String transaction_type;
	private String amount;
	private String acc_number;
	
	public TransactionDetails() {}

	public TransactionDetails(String transaction_id, Date dot, String transaction_type, String amount,
			String acc_number) {
		super();
		this.transaction_id = transaction_id;
		this.dot = dot;
		this.transaction_type = transaction_type;
		this.amount = amount;
		this.acc_number = acc_number;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public Date getDot() {
		return dot;
	}

	public void setDot(Date dot) {
		this.dot = dot;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getAcc_number() {
		return acc_number;
	}

	public void setAcc_number(String acc_number) {
		this.acc_number = acc_number;
	}

	@Override
	public String toString() {
		return "TransactionDetails [transaction_id=" + transaction_id + ", dot=" + dot + ", transaction_type="
				+ transaction_type + ", amount=" + amount + ", acc_number=" + acc_number + "]";
	}
	
}
