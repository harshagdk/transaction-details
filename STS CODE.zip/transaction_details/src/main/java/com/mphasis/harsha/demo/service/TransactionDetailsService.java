package com.mphasis.harsha.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.harsha.demo.entity.TransactionDetails;
import com.mphasis.harsha.demo.repository.TransactionDetailsRepository;



@Component("ts")
public class TransactionDetailsService {
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepo;
	
	public TransactionDetails create( TransactionDetails ad) 
	{
		return transactionDetailsRepo.save(ad);
	}
	public List<TransactionDetails> read() 
	{
		return transactionDetailsRepo.findAll();
	}
	public TransactionDetails read(String transaction_id) 
	{
		return transactionDetailsRepo.findById(transaction_id).get();
	}
	public TransactionDetails update(TransactionDetails ad) 
	{
		return transactionDetailsRepo.save(ad);
	}
	public void delete(String transaction_id) 
	{
		transactionDetailsRepo.delete(read(transaction_id));
	}
}
