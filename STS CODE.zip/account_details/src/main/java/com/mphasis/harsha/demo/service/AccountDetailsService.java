package com.mphasis.harsha.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.harsha.demo.entity.AccountDetails;
import com.mphasis.harsha.demo.repository.AccountDetailsRepository;



@Component("as")
public class AccountDetailsService {
	@Autowired
	private AccountDetailsRepository accountDetailsRepo;
	
	public AccountDetails create( AccountDetails ad) 
	{
		return accountDetailsRepo.save(ad);
	}
	public List<AccountDetails> read() 
	{
		return accountDetailsRepo.findAll();
	}
	public AccountDetails read(String acc_number) 
	{
		return accountDetailsRepo.findById(acc_number).get();
	}
	public AccountDetails update(AccountDetails ad) 
	{
		return accountDetailsRepo.save(ad);
	}
	public void delete(String acc_number) 
	{
		accountDetailsRepo.delete(read(acc_number));
	}
}
